/* Josh Carlson */
/* Web Tech team 5 */


(function($) {
	skel.init({
		reset: 'full',
		breakpoints: {
			// Global.
				global: {
					href: 'css/style.css',
				},

			// XLarge.
				xlarge: {
					href: 'css/style-xlarge.css',
				},	
		},
	});

})(jQuery);